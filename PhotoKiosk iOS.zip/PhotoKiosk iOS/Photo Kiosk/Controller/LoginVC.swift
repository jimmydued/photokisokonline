//
//  ViewController.swift
//  Photo Kiosk
//
//  Created by Harshil A. Kotecha on 04/08/17.
//  Copyright © 2017 Ravi. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var lblErrorMsg: UILabel!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func onClickBtnLogin(_ sender: UIButton) {
        let dict = [PARAM.EMAIL:txtEmail.text ?? "",
                    PARAM.PASSWORD:txtPassword.text ?? ""];
        AFHelper.sharedInstantance.getDataFromPathUsingPost(url: URLList.LOGIN, dictParam: dict) { (dict, error) in
            if ((dict?["success"] as? Int) == 1)  {
                UserDefaults.standard.set(dict?["success"], forKey: PARAM.STATUS)
                UserDefaults.standard.set(dict?["name"], forKey: PARAM.NAME)
                self.performSegue(withIdentifier: PARAM.SEGUETOHOME, sender: self)
            } else {
                self.lblErrorMsg.text = dict?["message"] as? String ?? ""
            }
        }
        
    }

}

