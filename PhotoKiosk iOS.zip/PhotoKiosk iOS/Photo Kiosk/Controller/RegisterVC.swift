//
//  RegisterVC.swift
//  Photo Kiosk
//
//  Created by elluminatimacmini3 on 05/08/17.
//  Copyright © 2017 Ravi. All rights reserved.
//

import UIKit
import TextFieldEffects
class RegisterVC: UIViewController {

    
    @IBOutlet weak var lblErrorMsg: UILabel!
    @IBOutlet var txtName: HoshiTextField!
    @IBOutlet var txtEmail: HoshiTextField!
    @IBOutlet var txtPassword: HoshiTextField!
    @IBOutlet var txtConfPassword: HoshiTextField!
    
    @IBOutlet var lblErrorName: UILabel!
    @IBOutlet var lblErrorEmail: UILabel!
    @IBOutlet var lblErrorPassword: UILabel!
    @IBOutlet var lblErrorConfPassword: UILabel!
    
    
    var validName:Bool = false
    var validEmail:Bool = false
    var validPassword:Bool = false
    var validConfPassword:Bool = false
    override func viewDidLoad() {
    super.viewDidLoad()
       
       
    }
    @IBAction func onClickBtnRegister(_ sender: UIButton) {
        if validName && validEmail && validPassword && validConfPassword {
            let dict:Dictionary<String,Any> =
                [PARAM.EMAIL:txtEmail.text ?? "",
                 PARAM.NAME :txtName.text ?? "",
                 PARAM.PASSWORD:txtPassword.text ?? ""];
            
            AFHelper.sharedInstantance.getDataFromPathUsingPost(url: URLList.REGISTER, dictParam: dict, completionHandler: { (dict, error) in
                if ((dict?["success"] as? Int) == 1)  {
                    self.lblErrorMsg.text = dict?["message"] as? String ?? "nil"
                    self.lblErrorMsg.textColor = UIColor.green
                } else {
                    print(dict?["message"] ?? "nil")
                    self.lblErrorMsg.text = dict?["message"] as? String ?? "nil"
                }
            })
        }
        
    }
    
    @IBAction func validation(_ sender: HoshiTextField) {
        
        if (sender.text != nil) {
            
            if sender == txtEmail {
                
                if isValidEmail(testStr: txtEmail.text!){
                    validEmail = true
                    lblErrorEmail.isHidden = true
                } else {
                    validEmail = false
                    lblErrorEmail.text = ErrorMsg.EMAILNOTVALID
                    lblErrorEmail.isHidden = false
                }
            }
            
            if sender == txtPassword {
                if (txtPassword.text?.characters.count)! >= 6 {
                    validPassword = true
                    lblErrorPassword.isHidden = true
                } else {
                    validPassword = false
                    lblErrorPassword.text = ErrorMsg.PASSWORDLENGTH
                    lblErrorPassword.isHidden = false
                }
                
            }
            
            if sender == txtConfPassword {
                if txtPassword.text == txtConfPassword.text {
                    validConfPassword = true
                    lblErrorConfPassword.isHidden = true
                } else {
                    validConfPassword = false
                    lblErrorConfPassword.text = ErrorMsg.PASSWORDNOTMATCH
                    lblErrorConfPassword.isHidden = false
                }
            }
            
        } else {
            
            if sender == txtName {
                lblErrorName.text = ErrorMsg.REQUIRED
                validName = false
                lblErrorName.isHidden = false
            }else if sender == txtEmail {
                lblErrorEmail.text = ErrorMsg.REQUIRED
                validEmail = false
                lblErrorEmail.isHidden = false
            } else if sender == txtPassword {
                lblErrorPassword.text = ErrorMsg.REQUIRED
                validPassword = false
                lblErrorPassword.isHidden = false
            } else if sender == txtConfPassword {
                lblErrorConfPassword.text = ErrorMsg.REQUIRED
                validConfPassword = false
                lblErrorConfPassword.isHidden = false
            }
            
        }
        
        if txtName.text?.characters.count == 0{
            lblErrorName.text = ErrorMsg.REQUIRED
            validName = false
            lblErrorName.isHidden = false
        } else {
            validName = true
            lblErrorName.isHidden = true
        }
    }
    
    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }

   

}
