//
//  HomeVC.swift
//  Photo Kiosk
//
//  Created by Harshil A. Kotecha on 05/08/17.
//  Copyright © 2017 Ravi. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet var lblStatus: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let name:String = UserDefaults.standard.value(forKey: PARAM.NAME) as? String ?? "";
        lblStatus.text = "Logged in user : \(name.capitalizingFirstLetter())"
       
    }

    @IBAction func onClickBtnLogout(_ sender: UIButton) {
        UserDefaults.standard.removeObject(forKey: PARAM.NAME)
        UserDefaults.standard.removeObject(forKey: PARAM.STATUS)
    }

    @IBAction func onClickBtnUrl(_ sender: UIButton) {
        
        if let url = URL(string: URLList.GOTO) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
        
        
    }

}
extension String {
    func capitalizingFirstLetter() -> String {
        let first = String(characters.prefix(1)).capitalized
        let other = String(characters.dropFirst())
        return first + other
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}
