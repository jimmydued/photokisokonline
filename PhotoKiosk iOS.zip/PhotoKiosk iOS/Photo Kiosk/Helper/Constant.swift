//
//  Constant.swift
//  Photo Kiosk
//
//  Created by elluminatimacmini3 on 05/08/17.
//  Copyright © 2017 Ravi. All rights reserved.
//

import Foundation

    struct URLList {
        static let BASEURL = "http://latestmovieinfo.com/"
        static let LOGIN = "demo/login.php"
        static let REGISTER = "demo/register.php"
        static let GOTO = "http://photokioskonline.com/"
    }
    struct  PARAM {
        static let STATUS = "status"
        static let NAME = "name"
        static let EMAIL = "email"
        static let PASSWORD = "password"
        static let SEGUETOHOME = "segueToHome"
    }
    struct ErrorMsg {
        static let EMAILNOTVALID = "Please enter valid email address"
        static let PASSWORDNOTMATCH = "Password dosn't match !"
        static let REQUIRED = "This field is required !"
        static let PASSWORDLENGTH = "Minimum lenght 6 character"
    }
