//
//  AFHelper.swift
//  Photo Kiosk
//
//  Created by elluminatimacmini3 on 05/08/17.
//  Copyright © 2017 Ravi. All rights reserved.
//

import Foundation
import Alamofire
import UIKit





class AFHelper: NSObject {
    
    override init() {
        
        super.init()
    }
    public static let sharedInstantance:AFHelper = {
        let instance = AFHelper()
        return instance
    }()
    
    
    
    func getDataFromPathUsingPost(url:String,dictParam:Dictionary<String, Any>,completionHandler: @escaping (NSDictionary?, Error?) -> ())
    {
        
        Alamofire.request(URLList.BASEURL+url, method: .post, parameters: dictParam,encoding: URLEncoding.default, headers: nil).responseJSON {
            response in
            
            switch response.result {
            case .success(let value):
                completionHandler(value as? NSDictionary, nil)
            case .failure(let error):
                 completionHandler(nil, error)
            }
        }
        
    }
   
}
